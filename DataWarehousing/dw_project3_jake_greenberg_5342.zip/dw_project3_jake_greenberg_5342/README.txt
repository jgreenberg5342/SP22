Project 3 Instruction.pdf -- Contains Project Outline and Deliverables List

Task_2_Deliverable.zip - The Visual Studio Project .zip file
Task_3_Deliverable.xlsx - Pivot Table for Task 3
Task_4_Deliverable.pdf - Answers to the Questions Document

misc/import_data.sql - Data used to populate SteelWheels Database
misc/SteelWheelsSales_MDX.mdx - MDX Code created for  all questions.